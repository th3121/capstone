





"Alert Notification Service",		"org.bluetooth.service.alert_notification",	0x1811
"Battery Service",	      	"org.bluetooth.service.battery_service",	0x180F	
"Blood Pressure",		"org.bluetooth.service.blood_pressure",	0x1810	
"Body Composition",		"org.bluetooth.service.body_composition",	0x181B	
"Bond Management",		"org.bluetooth.service.bond_management",	0x181E	
"Current Time Service",		"org.bluetooth.service.current_time",	0x1805	
"Cycling Power",		"org.bluetooth.service.cycling_power",	0x1818	
"Cycling Speed and Cadence",		"org.bluetooth.service.cycling_speed_and_cadence",	0x1816	
"Device Information",		"org.bluetooth.service.device_information",	0x180A	
"Generic Access",		"org.bluetooth.service.generic_access",	0x1800	
"Generic Attribute",		"org.bluetooth.service.generic_attribute",	0x1801	
"Glucose",		"org.bluetooth.service.glucose",	0x1808	
"Health Thermometer",		"org.bluetooth.service.health_thermometer",	0x1809	
"Heart Rate",		"org.bluetooth.service.heart_rate",	0x180D	
"Human Interface Device",		"org.bluetooth.service.human_interface_device",	0x1812	
"Immediate Alert",		"org.bluetooth.service.immediate_alert",	0x1802	
"Link Loss",		"org.bluetooth.service.link_loss",	0x1803	
"Location and Navigation",		"org.bluetooth.service.location_and_navigation",	0x1819	
"Next DST Change Service",		"org.bluetooth.service.next_dst_change",	0x1807	
"Phone Alert Status Service",		"org.bluetooth.service.phone_alert_status",	0x180E	
"Reference Time Update Service",	"org.bluetooth.service.reference_time_update",	0x1806	
"Running Speed and Cadence",		"org.bluetooth.service.running_speed_and_cadence",	0x1814	
"Scan Parameters",		"org.bluetooth.service.scan_parameters",	0x1813	
"Tx Power",		"org.bluetooth.service.tx_power",	0x1804	
"User Data",		"org.bluetooth.service.user_data",	0x181C	
"Weight Scale",		"org.bluetooth.service.weight_scale",	0x181D	
