bluez-experiments
=================

**Work in progress**

- Advertisment test: ```./at <advertisement time in ms> <UUID> <major number> <minor number> <RSSI calibration amount>```
- Example: ```./at 100 E2C51DB1DFF148D8B090D9F5871898E8 5 1023 -59```


- scantest.c - An example of scanning for BTLE devices
- advertisetest.c - An example of advertising




License
=======

MIT - See LICENSE file
